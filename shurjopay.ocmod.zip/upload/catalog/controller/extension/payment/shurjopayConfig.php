<?php
	/**
	 * this is the configuration file
	 * URLs are defined here
	 */
	//sandbox testing URL
	define('SHURJOPAY_SANDBOX_API','https://sandbox.shurjopayment.com/');
	//shurjopay live URL
	define('SHURJOPAY_LIVE_API','https://engine.shurjopayment.com/');

?>
