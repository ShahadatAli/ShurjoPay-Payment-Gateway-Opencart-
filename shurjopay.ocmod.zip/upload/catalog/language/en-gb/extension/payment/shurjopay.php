<?php

$_['text_title'] = 'Credit Card / Debit Card / bKash / Rocket / Nagad (shurjoPay)';
$_['text_success'] = 'Your Transaction is successful';
$_['text_failed'] = 'Your Transaction is failed';
